#!/bin/sh
set -e

GRAPHDB_URL="http://graphdb:7200"
REPO_ID="my-repo"

echo "Waiting for GraphDB..."
until curl -sf "$GRAPHDB_URL/rest/repositories" > /dev/null; do
  echo "  still waiting..."
  sleep 5
done
echo "GraphDB is up."

echo "Creating repository..."
curl -sf -X POST "$GRAPHDB_URL/rest/repositories" \
  -H "Content-Type: multipart/form-data" \
  -F "config=@/import/repo-config.ttl;type=text/turtle"
echo "Repository created."

echo "Importing knowledge_graph.ttl..."
curl -sf -X POST "$GRAPHDB_URL/repositories/$REPO_ID/statements" \
  -H "Content-Type: text/turtle" \
  --data-binary "@/import/knowledge_graph.ttl"
echo "Import done."