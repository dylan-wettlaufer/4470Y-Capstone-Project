{
  "properties" : {
    "current.location" : ""
  }
}